def summ_of_two(x: int, y: int) -> int:
    return x + y